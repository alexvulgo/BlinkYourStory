import SwiftUI

struct ProtagonistView: View {
    
    @State var LeftisWinking: Bool = false
    @State var RightisWinking: Bool = false
    
    //Card Animation
    
    @State private var currentIndex : Int = 0
    @State private var dragOffset : CGFloat = 5
    
    @State var viewModel = CardViewModel()
    
    @State var currentStory : CardViewModel
    
    @State var currentName : String = "Margherita"
    
    @State var currentDescription : String = "She is a great pizza lover and very good at cooking.  She is always ready to share a slice with her friends!"
    
    @EnvironmentObject var stateManager: StateManager
    
    func start() {
        stateManager.currentState = .setting
    }
    
    
    var body: some View {
        
        NavigationStack {
            
            VStack(){
                
                Spacer(minLength: /*@START_MENU_TOKEN@*/0/*@END_MENU_TOKEN@*/)
                
                HStack(){
                    Spacer(minLength: /*@START_MENU_TOKEN@*/0/*@END_MENU_TOKEN@*/)
                    
                    Text("Choose Protagonist")
                        .font(.largeTitle)
                        .bold()
                        .padding()
                    
                    Spacer(minLength: /*@START_MENU_TOKEN@*/0/*@END_MENU_TOKEN@*/)
                    
                }
                
                Text("Istruction: Right Blink to Scroll, Left Blink to Confirm")
                    .font(.title2)
                    .bold()
                
                Spacer()
                
                //Cards Animation
                ZStack () {
                    
                    ForEach(0..<viewModel.mainCards.count, id: \.self) { index in
                        
                        
                        Image(viewModel.mainCards[index].image)
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: 300, height: 500)
                            .cornerRadius(25)
                            .opacity(currentIndex == index ? 1.0 : 0.5)
                            .scaleEffect(currentIndex == index ? 1.2 : 0.7)
                            .offset(x: CGFloat(index - currentIndex) * 300 + dragOffset, y: 0)
                            .shadow(radius: 5)
                        
                        
                        
                        // Scroll Selection
                        
                    } .onChange(of: LeftisWinking) {
                        if (RightisWinking == false && LeftisWinking == true && currentIndex < 2) {
                            withAnimation {
                                currentIndex = currentIndex + 1
                                currentName = viewModel.mainCards[currentIndex].name
                                currentDescription = viewModel.mainCards[currentIndex].description
                            }
                            
                        } else if (RightisWinking == false && LeftisWinking == true && currentIndex == 2) {
                            currentIndex = 0
                            currentName = viewModel.mainCards[currentIndex].name
                            currentDescription = viewModel.mainCards[currentIndex].description
                        }
                    }
                    
                    
                    //Confirm Selection
                    
                    .onChange(of: RightisWinking) {
                        if (RightisWinking == true && LeftisWinking == false) {
                            //Changing View
                            currentStory.story.append(viewModel.mainCards[currentIndex])
                            start()
                        } 
                    }
                    
                   
                    
                }
                .frame(height: UIScreen.main.bounds.height/1.8)
                .padding(.horizontal,25) 
                
                //Spacer()
                
                //Camera position
                HStack(){
                    Spacer()
                    VStack(){
                        Text(currentName)
                            .font(.largeTitle)
                            .bold()
                            .padding()
                        
                        Text(currentDescription)
                            .font(.title2)
                        
                            .padding()
                        
                        
                    }.frame(width: 500, height: 200)
                    Spacer()
                    
                    //Camera
                    CustomContainer(LeftisWinking: $LeftisWinking, RightisWinking: $RightisWinking)
                        .frame(width: 250, height: 250)
                        .cornerRadius(15)
                    
                    Spacer()
                } 
                
                Spacer()
              
            }
            
        } 
        
    }
}



