import SwiftUI

struct ContentView: View {
    
    @State var eyeGazeActive: Bool = true
    @State var LeftisWinking: Bool = false
    @State var RightisWinking: Bool = false
    
    @State var story : CardViewModel
    
    //Detect the dark mode for change the title image
    @Environment(\.colorScheme) var colorScheme
    
    @EnvironmentObject var stateManager: StateManager
    
    func start() {
        stateManager.currentState = .mainScreen
    }
    
    func windowHeight() -> CGFloat {
        return UIScreen.main.bounds.size.height
    }
    
    func windowWidth() -> CGFloat {
        return UIScreen.main.bounds.size.width
    }
    
    var body: some View {
        
        NavigationStack {
            
            VStack(){
                
                //Page Title
                Image(colorScheme == .dark ? "Dark" : "Light")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    
                
             
                
                Text("Look at the result of your story!")
                    .font(.title2)
                
                Spacer(minLength: /*@START_MENU_TOKEN@*/0/*@END_MENU_TOKEN@*/)
                
                HStack {
                    
                    VStack{ 
                        
                        HStack() {
                            ForEach(story.story) { story in
                                VStack(alignment: .center){
                                    Text(story.name)
                                        .font(.title)
                                        .bold()
                                    Image(story.image)
                                        .resizable()
                                        .aspectRatio(contentMode: .fill)
                                        .frame(width: (windowWidth()/4 + 30), height: windowHeight()/3)
                                        .cornerRadius(15)
                                }
                            }
                            
                        }
                        
                    }
                    
                } 
                .padding(.horizontal,25)
                
                VStack(alignment: .center){
                    Text("Now use your imagination to create a fantastic story")
                    
                    Text("with the elements you have chosen!")
                       
                    Text("When does it take place? Who is the hero?")
                       
                    Text("Have fun sharing your stories with your friends")
                    Text("about the various adventures that come to mind!")
                        
                }
                .frame(width: windowWidth()-200)
                .fixedSize(horizontal: false, vertical: true)
                .font(.title2)
                .padding()
                
                
                
                
                
                Text("From the amazing Writer:")
                    .font(.title)
                    .bold()
                
                //Camera
                
                CustomContainer(LeftisWinking: $LeftisWinking, RightisWinking: $RightisWinking)
                    .frame(width: 250, height: 250)
                    .cornerRadius(15)
                
                Spacer()
                
                Button(action: {
                    story.story.removeAll()
                    start()
                    
                }, label: {
                    Text("Restart")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.blue)
                        .cornerRadius(10)
                })
                .padding(.bottom, 50)
                
                
            }
            
        }
    }
}


