import SwiftUI

struct SettingView: View {
    
    @State var LeftisWinking: Bool = false
    @State var RightisWinking: Bool = false
    
    //Card Animation
    
    @State private var currentIndex : Int = 0
    @State private var dragOffset : CGFloat = 5
    
    @State var viewModel = CardViewModel()
    
    @State var currentStory : CardViewModel
    
    @State var currentName : String = "Magical Forest"
    
    @State var currentDescription : String = "A forest that is magically lit up at night with colorful lights!"
    
    @EnvironmentObject var stateManager: StateManager
    
    func start() {
        stateManager.currentState = .antagonist
    }
    
    var body: some View {
        
        NavigationStack {
            
            VStack(){
                
                Spacer(minLength: /*@START_MENU_TOKEN@*/0/*@END_MENU_TOKEN@*/)
                
                HStack(){
                    Spacer(minLength: /*@START_MENU_TOKEN@*/0/*@END_MENU_TOKEN@*/)
                    
                    Text("Choose Setting")
                        .font(.largeTitle)
                        .bold()
                        .padding()
                    
                    Spacer(minLength: /*@START_MENU_TOKEN@*/0/*@END_MENU_TOKEN@*/)
                    
                }
                
                Text("Istruction: Right Blink to Scroll, Left Blink to Confirm")
                    .font(.title2)
                    .bold()
                
                Spacer()
                
                //Cards Animation
                ZStack () {
                    
                    ForEach(0..<viewModel.settingCards.count, id: \.self) { index in
                        
                        
                        Image(viewModel.settingCards[index].image)
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: 300, height: 500)
                            .cornerRadius(25)
                            .opacity(currentIndex == index ? 1.0 : 0.5)
                            .scaleEffect(currentIndex == index ? 1.2 : 0.7)
                            .offset(x: CGFloat(index - currentIndex) * 300 + dragOffset, y: 0)
                            .shadow(radius: 5)
                        
                        
                        
                        // Scroll Selection
                        
                    } .onChange(of: LeftisWinking) {
                        if (RightisWinking == false && LeftisWinking == true && currentIndex < 2) {
                            withAnimation {
                                currentIndex = currentIndex + 1
                                currentName = viewModel.settingCards[currentIndex].name
                                currentDescription = viewModel.settingCards[currentIndex].description
                            }
                            
                        } else if (RightisWinking == false && LeftisWinking == true && currentIndex == 2) {
                            currentIndex = 0
                            currentName = viewModel.settingCards[currentIndex].name
                            currentDescription = viewModel.settingCards[currentIndex].description
                        }
                    }
                    
                    
                    //Confirm Selection
                    
                    .onChange(of: RightisWinking) {
                        if (RightisWinking == true && LeftisWinking == false) {
                            //Changing View
                            currentStory.story.append(viewModel.settingCards[currentIndex])
                            start()
                        } 
                    }
                    
                    
                    
                }
                .frame(height: UIScreen.main.bounds.height/1.8)
                .padding(.horizontal,25) 
                
                
                
                //Camera position
                HStack(){
                    Spacer()
                    VStack(){
                        Text(currentName)
                            .font(.largeTitle)
                            .bold()
                            .padding()
                        
                        Text(currentDescription)
                            .font(.title2)
                        
                            .padding()
                        
                        
                    }.frame(width: 500, height: 200)
                    Spacer()
                    
                    //Camera
                    CustomContainer(LeftisWinking: $LeftisWinking, RightisWinking: $RightisWinking)
                        .frame(width: 250, height: 250)
                        .cornerRadius(15)
                    
                    Spacer()
                } 
                
                Spacer()
                
            }
            
        } 
        
    }
}



