import SwiftUI
import ARKit

struct MainView: View {
    
   
    @State var LeftisWinking: Bool = false
    @State var RightisWinking: Bool = false
    
    //Detect the dark mode for change the title image
    @Environment(\.colorScheme) var colorScheme
    
    //Manage views
    @EnvironmentObject var stateManager: StateManager
    
    func start() {
        stateManager.currentState = .intro
    }
    
    //functions for work with all ipad sizes 
    func windowHeight() -> CGFloat {
        return UIScreen.main.bounds.size.height
    }
    
    func windowWidth() -> CGFloat {
        return UIScreen.main.bounds.size.width
    }
    
    var body: some View {
        
        VStack() {
            
            //Page Title
            Image(colorScheme == .dark ? "Dark" : "Light")
            .resizable()
            .aspectRatio(contentMode: .fit)
            
            //Description
            VStack(alignment: .center){
                Text("Blink Your Story is specifically designed for children")
                
                Text("and teaches them the fundamentals of story telling.")
                
                Text("The aim is to provide a tool that enables children with")
                
                Text("mobility issues to write a story")
                
                 Text("with the aid of their imagination and eye control.")
                    
                Text("The application works by recognizing as commands")
                
                Text("the closing of the right or left eye.")
                
                Text("Become the writer of your personal story!")
                    .bold()
                
                
            }.frame(width: windowWidth()-200)
            .font(.title2)
            .fixedSize(horizontal: false, vertical: true)
            //.padding(.horizontal,20)
            
            //Camera
             
            CustomContainer(LeftisWinking: $LeftisWinking, RightisWinking: $RightisWinking)
                .frame(width: 250, height: 250)
                .cornerRadius(25)
                .padding()
            
            
            
            
            Button(action: {
                
                start()
                
            }, label: {
                Text("Start")
                    .font(.headline)
                    .foregroundColor(.white)
                    .padding()
                    .background(Color.blue)
                    .cornerRadius(10)
            })
            .padding(.bottom, 50)
            
            
            VStack(alignment: .center){
                Text("Note: This playground needs to run on an Ipad with camera access to detect the blink of the right and the left eye.")
                    .font(.headline)
                Text("The use of non-reflection glasses may cause inaccuracies in use.")
                    .font(.headline)
                Text("Please use your device in Portrait mode.")
                    .font(.headline)
            }.padding()
            
        }
    }
    
    
}

#if DEBUG
struct ContentView_Previews : PreviewProvider {
    static var previews: some View {
        MainView()
    }
}
#endif
