import SwiftUI
import Foundation


struct Card : Identifiable {
    var id: UUID = UUID()
    var name: String
    var description : String
    var image : String
}


class CardViewModel {
    
    var mainCards = [
        Card(name:"Margherita",description: "She is a great pizza lover and very good at cooking.  She is always ready to share a slice with her friends!",image: "Margherita"),
        Card(name:"Super Alex",description: "He is a super hero who flies as fast as a rocket and is always ready to help everyone with his powers!",image: "Alex"),
        Card(name:"Jesse",description: "As a powerful magician, it has the ability to perform the most mysterious magic and safeguard those who are close.",image: "Jesse")
    ]
    
    var settingCards = [
        Card(name:"Magical Forest",description: "A forest that is magically lit up at night with colorful lights!",image: "Woods"),
        Card(name:"City",description: "A city always full of people and lots of shops!",image: "City"),
        Card(name:"Mysterious Room",description: "A room appeared out of nowhere! What will it conceal?",image: "Room")
    ]
    
    var villainCards = [
        Card(name:"Sock-eater",description: "A terrible washing machine that loves to separate pairs of socks!",image: "Wash"),
        Card(name:"Lady Belluccio",description: "A professional thief ready to do anything to become rich!",image: "Lady"),
        Card(name:"The Scary Dentist",description: "A dentist who uses scary tools to frighten teeth!",image: "Dentist")
    ]
    
    var story : [Card] = []
}



