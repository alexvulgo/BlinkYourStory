import SwiftUI
import ARKit

struct IntroView: View {
    
    @State var LeftisWinking: Bool = false
    @State var RightisWinking: Bool = false
    
    @EnvironmentObject var stateManager: StateManager
    
    func start() {
        stateManager.currentState = .protagonist
    }
    
    
    func windowHeight() -> CGFloat {
        return UIScreen.main.bounds.size.height
    }
    
    func windowWidth() -> CGFloat {
        return UIScreen.main.bounds.size.width
    }
    
    var body: some View {
        NavigationStack{
            
            VStack{
             
                
                HStack(){
                    
                    
                    Text("How to create a Story")
                        .font(.largeTitle)
                        .bold()
                        .padding()
                    
                    
                }
                
                Text("Each story is a collection of ingredients that are joined together by the plot. The main ingredients of a story are:")
                .fixedSize(horizontal: false, vertical: true)
                    .font(.title2)
                    .padding(.horizontal,10)
                
                HStack(){
                    ZStack(alignment: .center){
                        
                        RoundedRectangle(cornerRadius: 15)
                            .foregroundStyle(.teal)
                            .shadow(radius: 5)
                            .frame(width: (windowWidth()/4+30), height: windowHeight()/3)
                        Text("Protagonist")
                            .foregroundStyle(Color(.white))
                            .font(.largeTitle)
                            .bold()
                    }
                    
                    Text("+")
                        .font(.largeTitle)
                        .bold()
                    
                    ZStack(alignment: .center){
                        RoundedRectangle(cornerRadius: 15)
                            .foregroundStyle(.orange)
                            .shadow(radius: 5)
                        .frame(width: (windowWidth()/4+30), height: windowHeight()/3)
                        Text("Setting")
                            .foregroundStyle(Color(.white))
                            .font(.largeTitle)
                            .bold()
                    }
                    
                    Text("+")
                        .font(.largeTitle)
                        .bold()
                    
                    ZStack(alignment: .center){
                        RoundedRectangle(cornerRadius: 15)
                            .foregroundStyle(.purple)
                            .shadow(radius: 5)
                            .frame(width: (windowWidth()/4+30), height: windowHeight()/3)
                        Text("Antagonist")
                            .foregroundStyle(Color(.white))
                            .font(.largeTitle)
                            .bold()
                    }
                }
                
                
                
                VStack(alignment: .leading) {
                    
                    Text("Protagonist:")
                        .font(.largeTitle)
                        .bold()
                    Text("The protagonist is the main character who leads the story and aims for positive outcomes.")
                    .fixedSize(horizontal: false, vertical: true)
                        .font(.title2)
                    
                    
                    Text("Setting:")
                        .font(.largeTitle)
                        .bold()
                    Text("The setting defines the time, place and duration of a story.")
                    .fixedSize(horizontal: false, vertical: true)
                        .font(.title2)
                    
                    
                    
                    Text("Antagonist:")
                        .font(.largeTitle)
                        .bold()
                    Text("The antagonist is the villain and wants to stop the protagonist from reaching its goal.")
                    .fixedSize(horizontal: false, vertical: true)
                        .font(.title2)
                    
                }.onChange(of: RightisWinking) {
                    if (RightisWinking == true && LeftisWinking == false) {
                        //Changing View
                        // let timeRemaining = 3
                        //let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
                        
                        start()
                    } 
                }
                .padding(.horizontal,25) 
                
                //Camera
                
                CustomContainer(LeftisWinking: $LeftisWinking, RightisWinking: $RightisWinking)
                    .frame(width: 250, height: 250)
                    .cornerRadius(15)
                
                Text("Close your left eye to proceed")
                    .font(.title2)
                    .bold()
                    .padding()
            }
            
        }
        
        
        
    }
    
}




struct IntroView_Previews : PreviewProvider {
    static var previews: some View {
        IntroView()
    }
}

