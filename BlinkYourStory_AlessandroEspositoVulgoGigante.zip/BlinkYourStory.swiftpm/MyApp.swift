import SwiftUI


enum AppState {
    case mainScreen
    case intro
    case protagonist
    case setting
    case antagonist
    case ending
}


class StateManager: ObservableObject{
    
    @Published var currentState = AppState.mainScreen
    
}
    


@main
struct MyApp: App {
    
    private var stateManager = StateManager()
    
    init() {
        
    }
    
    
    var body: some Scene {
        WindowGroup {
            SceneContainerView(story: CardViewModel())
                .environmentObject(stateManager)
        }
    }
}
