import SwiftUI

struct SceneContainerView: View {
    
    @EnvironmentObject var stateManager : StateManager
    
    @State var story : CardViewModel
    
    var body: some View {
        
        switch(stateManager.currentState){
        case .mainScreen:
            MainView()
                .environmentObject(stateManager)
            
        case .intro:
            IntroView()
                .environmentObject(stateManager)
            
        case .protagonist:
            ProtagonistView(currentStory : story)
                .environmentObject(stateManager)
            
        case .setting:
            SettingView(currentStory : story)
                .environmentObject(stateManager)
            
        case .antagonist:
            AntagonistView(currentStory : story)
                .environmentObject(stateManager)
            
        case .ending:
            ContentView(story : story)
                .environmentObject(stateManager)
            
        }
    }
}

#Preview {
    SceneContainerView(story:CardViewModel())
}
