import SwiftUI

struct AntagonistView: View {
    
    //Eye blink control
    @State var LeftisWinking: Bool = false
    @State var RightisWinking: Bool = false
    
    //Card Animation
    
    @State private var currentIndex : Int = 0
    @State private var dragOffset : CGFloat = 5
    
    @State var viewModel = CardViewModel()
    
    @State var currentStory : CardViewModel
    
    @State var currentName : String = "Sock-eater"
    
    @State var currentDescription : String = "A terrible washing machine that loves to seperare pairs of socks!"
    
    @EnvironmentObject var stateManager: StateManager
    
    func start() {
        stateManager.currentState = .ending
    }
    
    var body: some View {
        
        NavigationStack {
            
            VStack(){
                
                Spacer(minLength: /*@START_MENU_TOKEN@*/0/*@END_MENU_TOKEN@*/)
                
                HStack(){
                    Spacer(minLength: /*@START_MENU_TOKEN@*/0/*@END_MENU_TOKEN@*/)
                    
                    Text("Choose Antagonist")
                        .font(.largeTitle)
                        .bold()
                        .padding()
                    
                    Spacer(minLength: /*@START_MENU_TOKEN@*/0/*@END_MENU_TOKEN@*/)
                    
                }
                
                
                
                Text("Istruction: Right Blink to Scroll, Left Blink to Confirm")
                    .font(.title2)
                    .bold()
                
                Spacer()
                
                //Cards Animation
                ZStack () {
                    
                    ForEach(0..<viewModel.villainCards.count, id: \.self) { index in
                        
                        
                        Image(viewModel.villainCards[index].image)
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: 300, height: 500)
                            .cornerRadius(25)
                            .opacity(currentIndex == index ? 1.0 : 0.5)
                            .scaleEffect(currentIndex == index ? 1.2 : 0.7)
                            .offset(x: CGFloat(index - currentIndex) * 300 + dragOffset, y: 0)
                            .shadow(radius: 5)
                        
                        
                        
                        // Scroll Selection
                        
                    } .onChange(of: LeftisWinking) {
                        if (RightisWinking == false && LeftisWinking == true && currentIndex < 2) {
                            withAnimation {
                                currentIndex = currentIndex + 1
                                currentName = viewModel.villainCards[currentIndex].name
                                currentDescription = viewModel.villainCards[currentIndex].description
                            }
                            
                        } else if (RightisWinking == false && LeftisWinking == true && currentIndex == 2) {
                            currentIndex = 0
                            currentName = viewModel.villainCards[currentIndex].name
                            currentDescription = viewModel.villainCards[currentIndex].description
                        }
                    }
                    
                    
                    //Confirm Selection
                    
                    .onChange(of: RightisWinking) {
                        if (RightisWinking == true && LeftisWinking == false) {
                            //Changing View
                            currentStory.story.append(viewModel.villainCards[currentIndex])
                            start()
                        } 
                    }
                    
                    
                    
                }
                .frame(height: UIScreen.main.bounds.height/1.8)
                .padding(.horizontal,25) 
                
                //Spacer()
                
                //Camera position
                HStack(){
                    Spacer()
                    VStack(){
                        Text(currentName)
                            .font(.largeTitle)
                            .bold()
                            .padding()
                        
                        Text(currentDescription)
                            .font(.title2)
                        
                            .padding()
                        
                        
                    }.frame(width: 500, height: 200)
                    Spacer()
                    
                    //Camera
                    CustomContainer(LeftisWinking: $LeftisWinking, RightisWinking: $RightisWinking)
                        .frame(width: 250, height: 250)
                        .cornerRadius(15)
                    
                    Spacer()
                } 
                
                Spacer()
                
            }
            
        } 
        
    }
}



